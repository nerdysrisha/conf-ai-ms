//-------------------------------------------------------------------------------------------------
// <copyright file="HttpClient.h" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//-------------------------------------------------------------------------------------------------

#pragma once

#include <curl/curl.h>
#include <json/json.h>
#include <chrono>
#include <thread>
#include <math.h>
#include <map>
#include "AttestationLibTypes.h"

#define METADATA_HEADER "Metadata"
#define USER_AGENT_HEADER "User-Agent"
#define CONTENT_TYPE_HEADER "Content-Type"
#define AUTHORIZATION_HEADER "Authorization"
#define VM_ID_HEADER "x-ms-maa-vm-id"
#define SUBSCRIPTION_ID_HEADER "x-ms-maa-subscription-id"
#define CLIENT_TYPE_HEADER "x-ms-client-type"
#define MAA_RESPONSE_HEADER_REQUEST_ID "x-ms-request-id"
#define MAA_RESPONSE_HEADER_SERVICE_VERSION "x-ms-maa-service-version"

class HttpClient {
public:
    HttpClient();

    ~HttpClient();

    HttpClient(const HttpClient& other);

    HttpClient& operator=(const HttpClient& other) noexcept;

    HttpClient(HttpClient&& other) noexcept;

    HttpClient& operator=(HttpClient&& other) noexcept;
    
    enum class HttpVerb {
        GET,
        POST,
        PUT,
        PATCH
    };

    struct TraceData {
        std::string data;
    };

    static inline const char* ToString(HttpVerb http_verb) {
        switch (http_verb) {
            case HttpVerb::GET:
                return "GET";
            case HttpVerb::POST:
                return "POST";
            case HttpVerb::PUT:
                return "PUT";
            case HttpVerb::PATCH:
                return "PATCH";
            default:
                return "UNKNOWN";
        }
    }

    /**
     * @brief This function will be used to send a http request 
     * @param[out] http_response The response received from the endpoint.
     * @param[in] url, the url endpoint to be called
     * @param[in] http_verb, the HTTP verb (GET or POST)
     * @param[in] request_body, the request body. This is expected for any POST calls.
     * @return On success, the function returns
     * AttestationResult::ErrorCode::SUCCESS and the http_response is set to the
     * response from the end point.
     * On failure, AttestationResult::ErrorCode is returned.
     */
    attest::AttestationResult InvokeHttpRequest(std::string& http_response,
                                                    const std::string& url,
                                                    const HttpClient::HttpVerb& http_verb,
                                                    const std::string& request_body = std::string());
    /**
     * @brief This function will be used to URL encode the data
     * @param[in] data, the data to be URL encoded
     * @return On success, URL encoded string is returned
     */
    std::string UrlEncode(const std::string& data);

    /**
     * @brief This function will be used to set Https Request headers
     * @param[in] key, key of key value pair of header
     * @param[in] value, value of the key value pair of header
     */
    void setHeader(const std::string& key,
                    const std::string& value);
    /**
     * @brief This function will ne used to add SSL certs
     */
    void setClientCert();

    /**
     * @brief This function used to set no proxy
     * @param[in] hosts, comma separated hosts list which do not require proxy to get reached
     */
    void disableProxyFor(const std::string&  hosts);

    /**
     * @brief This function used to set manual proxy.
     * @param[in] proxy, 
     */
    void setProxy(const std::string& proxy);

    /**
     * @brief This function used to set timeout.
     * @param[in] timeout, timeout for the request
     */
    void setTimeOut(long timeout_seconds);

    /**
     * @brief This function used to set backoff time base for retry logic.
     * @param[in] backoff_seconds, base backoff time in seconds for exponential backoff
     */
    void setBackoffTime(long backoff_seconds);

    /**
     * @brief This function used to set maximum number of retries.
     * @param[in] max_retries, maximum number of retries for requests
     */
    void setMaxRetries(uint8_t max_retries);

    /**
     *  @brief This function will be used to increase verbosity.
     */
    void enableVerboseLogging();

    /**
    *   @brief This function will be used to enable header logging. 
    */
    void enableHeaderLogging();

#ifdef UNIT_TEST
    static std::string ExtractHeaderValueHelper(std::string& header);
#endif

private:
    /**
     * @brief CURL Callback to write response to a user specified pointer
     */
    static size_t WriteResponseCallback(void* contents, size_t size, size_t nmemb, void* response);

    /**
    * @brief CURL Callback to write response header to a user specified pointer
     */
    static size_t WriteMAAResponseHeaderCallback(void* contents, size_t size, size_t nmemb, void* response);

    /**
     * @brief Extracts header value 
     */
    static std::string ExtractHeaderValue(std::string& header);

    /**
     * @brief CURL Callback to write verbose logs
     */
    static int traceCallback(CURL* handle, curl_infotype type, char* data, size_t size, void* trace_data);

    /**
     * @brief CURL pointer used to set request parameters.
     */
    CURL* m_curl;

    /**
     * @brief curl request timeout
     */
    long m_request_timeout = 100L;

    /**
     * @brief backoff time base for exponential backoff in seconds
     */
    long m_backoff_time_seconds = 5L;

    /**
     * @brief maximum number of retries for HTTP requests
     */
    uint8_t m_max_retries = 3;

    /**
     *  @brief Used in curl verbose logging
     */
    bool m_verbose_logging = false;

    /**
     *  @brief curl header logging
     */
    bool m_header_logging = false;

    /**
     * @brief Used in curl trace callback to write verbose logs.
     */
    TraceData trace_data;

    /**
     * @brief http request headers
     */
    std::map<std::string, std::string> m_headers;

    /**
	 * @brief no proxy list
     */
    std::string no_proxy_list;

    /**
     * @brief manual proxy
     */
    std::string m_proxy;

    /**
     * @brief This function will generate jitter before retrying again. 
     */
    int generateRandomJitter();

    /**
     * @brief Logs an error message and sets the result code and description.
     * @param[out] result The result object to set the error code and description.
     * @param[in] description The error description.
     * @param[in] code The error code.
     */
    void logAndSetResult(attest::AttestationResult& result, const std::string& description, attest::AttestationResult::ErrorCode code);
    
    /**
     * @brief Sleeps for an exponentially increasing backoff period with jitter.
     * @param[in] retries The number of retries.
     */
    void sleepWithBackoff(uint8_t retries);

    /**
     * @brief Checks if the response code indicates a handled server failure.
     * @param[in] response_code The HTTP response code.
     * @return True if the response code indicates a handled server failure, false otherwise.
     */
    bool isHandledServerFailure(long response_code);

    /**
     * @brief Checks if the CURLcode indicates a handled client failure.
     * @param[in] res The CURLcode.
     * @return True if the CURLcode indicates a handled client failure, false otherwise.
     */
    bool isHandledClientFailure(CURLcode res);

    /**
     * @brief This function helps in clean up after http request completes.
     */
    void cleanUp();
};